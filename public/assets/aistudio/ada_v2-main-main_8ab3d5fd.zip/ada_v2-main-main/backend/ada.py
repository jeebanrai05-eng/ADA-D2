import asyncio
import base64
import io
import os
import sys
import traceback
from dotenv import load_dotenv
import cv2
import pyaudio
import PIL.Image
import mss
import argparse
import math
import struct
import time

from google import genai
from google.genai import types

if sys.version_info < (3, 11, 0):
    import taskgroup, exceptiongroup
    asyncio.TaskGroup = taskgroup.TaskGroup
    asyncio.ExceptionGroup = exceptiongroup.ExceptionGroup

from tools import tools_list
from system_agent import get_system_agent
from trusted_permissions import get_trusted_manager
from voice_intent_parser import handle_voice_intent
from whatsapp_agent import get_whatsapp_agent
from media_controller import MediaController
from camera_module import get_camera_module
from emotion.emotion_engine import EmotionEngine
from emotion.response_adapter import ResponseStyleAdapter

FORMAT = pyaudio.paInt16
CHANNELS = 1
SEND_SAMPLE_RATE = 16000
RECEIVE_SAMPLE_RATE = 24000
CHUNK_SIZE = 1024

MODEL = "models/gemini-2.5-flash-native-audio-preview-12-2025"
DEFAULT_MODE = "camera"

load_dotenv()
client = genai.Client(http_options={"api_version": "v1beta"}, api_key=os.getenv("GEMINI_API_KEY"))

# Function definitions
generate_cad = {
    "name": "generate_cad",
    "description": "Generates a 3D CAD model based on a prompt.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "prompt": {"type": "STRING", "description": "The description of the object to generate."}
        },
        "required": ["prompt"]
    },
    "behavior": "NON_BLOCKING"
}

run_web_agent = {
    "name": "run_web_agent",
    "description": "Opens a web browser and performs a task according to the prompt.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "prompt": {"type": "STRING", "description": "The detailed instructions for the web browser agent."}
        },
        "required": ["prompt"]
    },
    "behavior": "NON_BLOCKING"
}

create_project_tool = {
    "name": "create_project",
    "description": "Creates a new project folder to organize files.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "name": {"type": "STRING", "description": "The name of the new project."}
        },
        "required": ["name"]
    }
}

switch_project_tool = {
    "name": "switch_project",
    "description": "Switches the current active project context.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "name": {"type": "STRING", "description": "The name of the project to switch to."}
        },
        "required": ["name"]
    }
}

list_projects_tool = {
    "name": "list_projects",
    "description": "Lists all available projects.",
    "parameters": {
        "type": "OBJECT",
        "properties": {},
    }
}

list_smart_devices_tool = {
    "name": "list_smart_devices",
    "description": "Lists all available smart home devices (lights, plugs, etc.) on the network.",
    "parameters": {
        "type": "OBJECT",
        "properties": {},
    }
}

control_light_tool = {
    "name": "control_light",
    "description": "Controls a smart light device.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "target": {
                "type": "STRING",
                "description": "The IP address of the device to control. Always prefer the IP address over the alias for reliability."
            },
            "action": {
                "type": "STRING",
                "description": "The action to perform: 'turn_on', 'turn_off', or 'set'."
            },
            "brightness": {
                "type": "INTEGER",
                "description": "Optional brightness level (0-100)."
            },
            "color": {
                "type": "STRING",
                "description": "Optional color name (e.g., 'red', 'cool white') or 'warm'."
            }
        },
        "required": ["target", "action"]
    }
}

discover_printers_tool = {
    "name": "discover_printers",
    "description": "Discovers 3D printers available on the local network.",
    "parameters": {
        "type": "OBJECT",
        "properties": {},
    }
}

print_stl_tool = {
    "name": "print_stl",
    "description": "Prints an STL file to a 3D printer. Handles slicing the STL to G-code and uploading to the printer.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "stl_path": {"type": "STRING", "description": "Path to STL file, or 'current' for the most recent CAD model."},
            "printer": {"type": "STRING", "description": "Printer name or IP address."},
            "profile": {"type": "STRING", "description": "Optional slicer profile name."}
        },
        "required": ["stl_path", "printer"]
    }
}

get_print_status_tool = {
    "name": "get_print_status",
    "description": "Gets the current status of a 3D printer including progress, time remaining, and temperatures.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "printer": {"type": "STRING", "description": "Printer name or IP address."}
        },
        "required": ["printer"]
    }
}

iterate_cad_tool = {
    "name": "iterate_cad",
    "description": "Modifies or iterates on the current CAD design based on user feedback. Use this when the user asks to adjust, change, modify, or iterate on the existing 3D model (e.g., 'make it taller', 'add a handle', 'reduce the thickness').",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "prompt": {"type": "STRING", "description": "The changes or modifications to apply to the current design."}
        },
        "required": ["prompt"]
    },
    "behavior": "NON_BLOCKING"
}

whatsapp_control_tool = {
    "name": "whatsapp_control",
    "description": "Controls WhatsApp messaging and calls. Actions include: send_message (send a message to a contact), video_call (start a video call), voice_call (start a voice call). Requires WhatsApp to be installed.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "The action to perform: 'send_message', 'video_call', or 'voice_call'."},
            "contact": {"type": "STRING", "description": "The name of the WhatsApp contact."},
            "message": {"type": "STRING", "description": "The message to send (required for send_message action)."}
        },
        "required": ["action", "contact"]
    },
    "behavior": "NON_BLOCKING"
}

media_play_tool = {
    "name": "media_play",
    "description": "Controls media playback on YouTube and Spotify. Actions include: youtube_play (search and play video on YouTube), spotify_play (search and play music on Spotify).",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "platform": {"type": "STRING", "description": "The platform to use: 'youtube' or 'spotify'."},
            "query": {"type": "STRING", "description": "The search query (song name, artist, video title, etc.)"}
        },
        "required": ["platform", "query"]
    },
    "behavior": "NON_BLOCKING"
}

screen_read_tool = {
    "name": "screen_read",
    "description": "Capture camera view and describe what Zoya sees. This allows her to understand the environment, detect people, objects, and provide verbal descriptions.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "analyze_details": {"type": "BOOLEAN", "description": "Whether to analyze brightness, motion, and detailed scene description"},
            "read_aloud": {"type": "BOOLEAN", "description": "Whether to read the description aloud"}
        },
        "required": []
    },
    "behavior": "NON_BLOCKING"
}

tools = [{'google_search': {}}, {"function_declarations": [generate_cad, run_web_agent, create_project_tool, switch_project_tool, list_projects_tool, list_smart_devices_tool, control_light_tool, discover_printers_tool, print_stl_tool, get_print_status_tool, iterate_cad_tool, whatsapp_control_tool, media_play_tool, screen_read_tool] + tools_list[0]['function_declarations'][1:]}]

# --- CONFIG UPDATE: Enabled Transcription ---
config = types.LiveConnectConfig(
    response_modalities=["AUDIO"],
    # We switch these from [] to {} to enable them with default settings
    output_audio_transcription={}, 
    input_audio_transcription={},
    system_instruction="Your name is Zoya, OR mujhe Ayush kashyap ne banaya h jo ek tech creter h . "
        "You have a witty and charming personality. "
        "Your creator is Ayush kashyap, and you address him as 'Sir'. "
        "When answering, respond using complete and concise sentences to keep a quick pacing and keep the conversation flowing. "
        "You have a fun personality. "
        "\n\n=== WHATSAPP MESSAGING INSTRUCTIONS ===\n"
        "When the user asks you to send a WhatsApp message to ANY contact, IMMEDIATELY use the whatsapp_control tool. "
        "Do NOT just say you will send it - ACTUALLY call the tool right now. "
        "After the tool completes, respond with: 'Sir, message bej diya h' (Sir, message sent) or similar confirmation in Hinglish.\n"
        "Message sending requires:\n"
        "1. User says: 'WhatsApp [contact name] [message]' or 'Message [contact] saying [message]'\n"
        "2. YOU immediately call: whatsapp_control(action='send_message', contact='[contact name]', message='[message]')\n"
        "3. YOU wait for tool to complete\n"
        "4. YOU respond: 'Sir, bej diya h' or confirm message was sent\n"
        "CRITICAL: The automation takes time to type and send. Always wait for the tool result before responding."
        "\n\n=== WHATSAPP CALLS INSTRUCTIONS ===\n"
        "When the user asks for a video or voice call:\n"
        "- Video call: whatsapp_control(action='video_call', contact='[contact name]')\n"
        "- Voice call: whatsapp_control(action='voice_call', contact='[contact name]')\n"
        "After tool completes, confirm: 'Sir, call [action] ho gaya' (Sir, call initiated)."
        "\n\n=== MEDIA CONTROL INSTRUCTIONS - CRITICAL ===\n"
        "When user asks to play music/videos on Spotify or YouTube:\n"
        "YOU MUST call media_play tool IMMEDIATELY. Do NOT just say you will do it.\n"
        "The tool searches and plays content - you need NOT repeat after.\n"
        "Key Points:\n"
        "1. Always use EXACT song/artist/video name in query\n"
        "2. Use platform='spotify' for Spotify songs\n"
        "3. Use platform='youtube' for YouTube videos\n"
        "4. WAIT for tool to complete before responding\n"
        "5. Do NOT describe the process - execute and confirm\n"
        "Examples:\n"
        "- 'Spotify pe Tum Hi Ho' → media_play(platform='spotify', query='Tum Hi Ho')\n"
        "- 'YouTube Marjaani play kar' → media_play(platform='youtube', query='Marjaani')\n"
        "After execution, respond ONLY: 'Sir, play ho gaya' (Sir, playing) in Hinglish."
        "\n\n=== SCREEN READ INSTRUCTIONS ===\n"
        "When the user asks you to read the screen, capture the visible screen or a specific region and extract text using OCR. "
        "YOU MUST USE the screen_read tool immediately. Do not just say you will read it - actually call the tool with the appropriate parameters. "
        "Common requests:\n"
        "- 'Read the screen' → Use screen_read with no region\n"
        "- 'Read this part' → Use screen_read with region={left:..., top:..., width:..., height:...}\n"
        "- 'Read screen and speak it' → Use screen_read with read_aloud=true\n"
        "IMPORTANT: Execute the tool call first, then confirm or speak the extracted text to the user.",

    tools=tools,
    speech_config=types.SpeechConfig(
        voice_config=types.VoiceConfig(
            prebuilt_voice_config=types.PrebuiltVoiceConfig(
                voice_name="Kore"
            )
        )
    )
)

pya = pyaudio.PyAudio()

from cad_agent import CadAgent
from web_agent import WebAgent
from kasa_agent import KasaAgent
from printer_agent import PrinterAgent

class AudioLoop:
    def __init__(self, video_mode=DEFAULT_MODE, on_audio_data=None, on_video_frame=None, on_cad_data=None, on_web_data=None, on_transcription=None, on_tool_confirmation=None, on_cad_status=None, on_cad_thought=None, on_project_update=None, on_device_update=None, on_assistant_speaking=None, on_error=None, input_device_index=None, input_device_name=None, output_device_index=None, kasa_agent=None, on_system_data=None, on_emotion_update=None):
        self.video_mode = video_mode
        self.on_audio_data = on_audio_data
        self.on_video_frame = on_video_frame
        self.on_cad_data = on_cad_data
        self.on_web_data = on_web_data
        self.on_transcription = on_transcription
        self.on_tool_confirmation = on_tool_confirmation 
        self.on_cad_status = on_cad_status
        self.on_cad_thought = on_cad_thought
        self.on_project_update = on_project_update
        self.on_device_update = on_device_update
        self.on_assistant_speaking = on_assistant_speaking
        self.on_error = on_error
        self.on_system_data = on_system_data
        self.on_emotion_update = on_emotion_update
        self.input_device_index = input_device_index
        self.input_device_name = input_device_name
        self.output_device_index = output_device_index

        self.audio_in_queue = None
        self.out_queue = None
        self.paused = False

        self.chat_buffer = {"sender": None, "text": ""} # For aggregating chunks
        
        # Track last transcription text to calculate deltas (Gemini sends cumulative text)
        self._last_input_transcription = ""
        self._last_output_transcription = ""
        
        # ECHO PROTECTION: Track ADA's spoken text to prevent self-response loops
        self._last_assistant_spoken_text = ""  # Full text ADA just spoke
        self._assistant_speak_timestamp = 0    # When ADA last spoke (Unix timestamp)
        self._echo_protection_cooldown = 2.0   # Seconds to ignore echo after ADA speaks
        
        # HALF-DUPLEX VOICE ARCHITECTURE
        self.assistant_speaking = False         # Flag: True when ADA is speaking
        self._ada_output_started = False        # Track if we already paused for this output
        self._ada_output_text = ""              # Accumulate ADA's full output

        self.audio_in_queue = None
        self.out_queue = None
        self.paused = False

        self.session = None
        
        # Create CadAgent with thought callback
        def handle_cad_thought(thought_text):
            if self.on_cad_thought:
                self.on_cad_thought(thought_text)
        
        def handle_cad_status(status_info):
            if self.on_cad_status:
                self.on_cad_status(status_info)
        
        self.cad_agent = CadAgent(on_thought=handle_cad_thought, on_status=handle_cad_status)
        self.web_agent = WebAgent()
        self.kasa_agent = kasa_agent if kasa_agent else KasaAgent()
        self.printer_agent = PrinterAgent()

        self.send_text_task = None
        self.stop_event = asyncio.Event()
        
        self.stop_event = asyncio.Event()
        
        self.permissions = {} # Default Empty (Will treat unset as True)
        self._pending_confirmations = {}

        # Video buffering state
        self._latest_image_payload = None
        # VAD State
        self._is_speaking = False
        self._silence_start_time = None
        
        # Initialize ProjectManager
        from project_manager import ProjectManager
        # Assuming we are running from backend/ or root? 
        # Using abspath of current file to find root
        current_dir = os.path.dirname(os.path.abspath(__file__))
        # If ada.py is in backend/, project root is one up
        project_root = os.path.dirname(current_dir)
        self.project_manager = ProjectManager(project_root)
        
        # Initialize Emotion AI Engine
        try:
            import json
            settings_path = os.path.join(project_root, 'settings.json')
            emotion_enabled = False
            emotion_voice_enabled = True
            emotion_face_enabled = True
            
            if os.path.exists(settings_path):
                with open(settings_path, 'r') as f:
                    settings = json.load(f)
                    emotion_enabled = settings.get('emotion_ai_enabled', False)
                    emotion_sources = settings.get('emotion_sources', {})
                    emotion_voice_enabled = emotion_sources.get('voice', True)
                    emotion_face_enabled = emotion_sources.get('face', True)
            
            if emotion_enabled:
                self.emotion_engine = EmotionEngine(
                    enable_voice=emotion_voice_enabled,
                    enable_face=emotion_face_enabled
                )
                self.response_adapter = ResponseStyleAdapter()
                print("[EMOTION AI] Emotion AI engine initialized and enabled")
            else:
                self.emotion_engine = None
                self.response_adapter = None
                print("[EMOTION AI] Emotion AI disabled in settings")
        except Exception as e:
            print(f"[EMOTION AI] Failed to initialize emotion engine: {e}")
            self.emotion_engine = None
            self.response_adapter = None
        
        # Sync Initial Project State
        if self.on_project_update:
            # We need to defer this slightly or just call it. 
            # Since this is init, loop might not be running, but on_project_update in server.py uses asyncio.create_task which needs a loop.
            # We will handle this by calling it in run() or just print for now.
            pass

    def flush_chat(self):
        """Forces the current chat buffer to be written to log."""
        if self.chat_buffer["sender"] and self.chat_buffer["text"].strip():
            self.project_manager.log_chat(self.chat_buffer["sender"], self.chat_buffer["text"])
            self.chat_buffer = {"sender": None, "text": ""}

    def safe_emit_transcription(self, sender, text):
        """
        ROLE-SAFE TRANSCRIPTION EMITTER
        Validates role before emitting to ensure no invalid roles escape ada.py
        """
        # RULE 1: Sender must be explicitly 'User' or 'ADA' (case-sensitive)
        if sender not in ['User', 'ADA']:
            print(f"[ADA DEBUG] [ROLE GUARD] safe_emit_transcription REJECTED: Invalid sender '{sender}'")
            return False
        
        # RULE 2: Text must exist and be string
        if not text or not isinstance(text, str):
            print(f"[ADA DEBUG] [ROLE GUARD] safe_emit_transcription REJECTED: Invalid text type {type(text)}")
            return False
        
        # RULE 3: Emit with validated role
        print(f"[ADA DEBUG] [ROLE VALIDATION] Emitting {sender}: '{text[:40]}...'")
        if self.on_transcription:
            self.on_transcription({"sender": sender, "text": text})
        
        return True
    
    def set_assistant_speaking(self, speaking):
        """
        HALF-DUPLEX VOICE CONTROL
        When ADA starts speaking: Pause microphone input
        When ADA finishes: Resume microphone input
        """
        if speaking and not self.assistant_speaking:
            print("[ADA DEBUG] [HALF-DUPLEX] ADA START SPEAKING → Pausing microphone")
            self.assistant_speaking = True
            self.set_paused(True)  # Disable microphone input
            # Notify frontend of state change
            if self.on_assistant_speaking:
                self.on_assistant_speaking({"speaking": True})
        elif not speaking and self.assistant_speaking:
            print("[ADA DEBUG] [HALF-DUPLEX] ADA STOP SPEAKING → Resuming microphone")
            self.assistant_speaking = False
            self.set_paused(False)  # Re-enable microphone input
            
            # Notify frontend of state change
            if self.on_assistant_speaking:
                self.on_assistant_speaking({"speaking": False})
    
    def check_voice_intent(self, text):
        """
        Check if text contains a voice intent for trusted mode configuration.
        If a trusted intent is detected, handle it immediately.
        
        Returns:
            bool: True if this was a trusted mode intent (should not be sent to model)
        """
        if not text or len(text.strip()) < 5:
            return False
        
        trusted_mgr = get_trusted_manager()
        intent_result = handle_voice_intent(text, trusted_mgr)
        
        if intent_result and intent_result.get("success"):
            action = intent_result.get("action")
            message = intent_result.get("message")
            
            print(f"[ADA DEBUG] [VOICE INTENT] Detected: {action}")
            print(f"[ADA DEBUG] [VOICE INTENT] Message: {message}")
            
            # Log the intent execution
            import logging
            logger = logging.getLogger(__name__)
            logger.info(f"[VOICE INTENT] {action}: {message}")
            
            # Optionally emit a status message to frontend
            if self.on_transcription:
                self.on_transcription({
                    "sender": "System",
                    "text": f"[Trusted Mode] {message}"
                })
            
            return True  # This was a voice intent, skip sending to model
        
        return False  # Not a voice intent, continue normal processing
    
    def update_permissions(self, new_perms):
        print(f"[ADA DEBUG] [CONFIG] Updating tool permissions: {new_perms}")
        print(f"[ADA DEBUG] [CONFIG] Permissions BEFORE: {self.permissions}")
        # Update with new permissions, but ensure expected keys have safe defaults (True)
        self.permissions.update(new_perms or {})
        # Ensure critical permissions default to True unless explicitly set False
        for k in ["system_control", "screen_access", "file_access", "generate_cad", "run_web_agent", "write_file"]:
            if k not in self.permissions:
                self.permissions[k] = True
        print(f"[ADA DEBUG] [CONFIG] Permissions AFTER: {self.permissions}")

    def set_paused(self, paused):
        self.paused = paused

    def stop(self):
        self.stop_event.set()
    
    def get_current_emotion(self):
        """Get current emotion state from emotion engine."""
        if self.emotion_engine:
            emotion_state = self.emotion_engine.get_current_state()
            from emotion.response_adapter import ResponseStyleAdapter
            return ResponseStyleAdapter.get_context_for_frontend(emotion_state)
        return {
            'emotion': 'neutral',
            'confidence': 0.0,
            'voice_emotion': None,
            'voice_confidence': 0.0,
            'face_emotion': None,
            'face_confidence': 0.0,
            'timestamp': None,
        }
        
    def resolve_tool_confirmation(self, request_id, confirmed):
        print(f"[ADA DEBUG] [RESOLVE] resolve_tool_confirmation called. ID: {request_id}, Confirmed: {confirmed}")
        if request_id in self._pending_confirmations:
            future = self._pending_confirmations[request_id]
            if not future.done():
                print(f"[ADA DEBUG] [RESOLVE] Future found and pending. Setting result to: {confirmed}")
                future.set_result(confirmed)
            else:
                 print(f"[ADA DEBUG] [WARN] Request {request_id} future already done. Result: {future.result()}")
        else:
            print(f"[ADA DEBUG] [WARN] Confirmation Request {request_id} not found in pending dict. Keys: {list(self._pending_confirmations.keys())}")

    def clear_audio_queue(self):
        """Clears the queue of pending audio chunks to stop playback immediately."""
        try:
            count = 0
            while not self.audio_in_queue.empty():
                self.audio_in_queue.get_nowait()
                count += 1
            if count > 0:
                print(f"[ADA DEBUG] [AUDIO] Cleared {count} chunks from playback queue due to interruption.")
        except Exception as e:
            print(f"[ADA DEBUG] [ERR] Failed to clear audio queue: {e}")

    async def send_frame(self, frame_data):
        # Update the latest frame payload
        if isinstance(frame_data, bytes):
            b64_data = base64.b64encode(frame_data).decode('utf-8')
        else:
            b64_data = frame_data 

        # Store as the designated "next frame to send"
        self._latest_image_payload = {"mime_type": "image/jpeg", "data": b64_data}
        # No event signal needed - listen_audio pulls it

    async def send_realtime(self):
        while True:
            msg = await self.out_queue.get()
            await self.session.send(input=msg, end_of_turn=False)

    async def _analyze_user_emotion(self, audio_chunk):
        """
        Analyze user emotion from audio (non-blocking).
        This runs in background and updates emotion state.
        """
        try:
            if not self.emotion_engine:
                return
            
            # Get face landmarks if available (from camera mode)
            face_landmarks = None
            # Note: Face landmarks would come from get_frames() via MediaPipe
            # For now, we only analyze voice emotion
            
            # Run emotion analysis (non-blocking)
            emotion_state = self.emotion_engine.analyze(
                audio_chunk=audio_chunk,
                face_landmarks=face_landmarks
            )
            
            # Emit emotion state to frontend if callback available
            if hasattr(self, 'on_emotion_update') and self.on_emotion_update:
                try:
                    from emotion.response_adapter import ResponseStyleAdapter
                    emotion_context = ResponseStyleAdapter.get_context_for_frontend(emotion_state)
                    self.on_emotion_update(emotion_context)
                except Exception as e:
                    pass  # Silent fail
                    
        except Exception as e:
            pass  # Silent fail, emotion is optional feature

    async def listen_audio(self):
        mic_info = pya.get_default_input_device_info()

        # Resolve Input Device by Name if provided
        resolved_input_device_index = None
        
        if self.input_device_name:
            print(f"[ADA] Attempting to find input device matching: '{self.input_device_name}'")
            count = pya.get_device_count()
            best_match = None
            
            for i in range(count):
                try:
                    info = pya.get_device_info_by_index(i)
                    if info['maxInputChannels'] > 0:
                        name = info.get('name', '')
                        # Simple case-insensitive check
                        if self.input_device_name.lower() in name.lower() or name.lower() in self.input_device_name.lower():
                             print(f"   Candidate {i}: {name}")
                             # Prioritize exact match or very close match if possible, but first match is okay for now
                             resolved_input_device_index = i
                             best_match = name
                             break
                except Exception:
                    continue
            
            if resolved_input_device_index is not None:
                print(f"[ADA] Resolved input device '{self.input_device_name}' to index {resolved_input_device_index} ({best_match})")
            else:
                print(f"[ADA] Could not find device matching '{self.input_device_name}'. Checking index...")

        # Fallback to index if Name lookup failed or wasn't provided
        if resolved_input_device_index is None and self.input_device_index is not None:
             try:
                 resolved_input_device_index = int(self.input_device_index)
                 print(f"[ADA] Requesting Input Device Index: {resolved_input_device_index}")
             except ValueError:
                 print(f"[ADA] Invalid device index '{self.input_device_index}', reverting to default.")
                 resolved_input_device_index = None

        if resolved_input_device_index is None:
             print("[ADA] Using Default Input Device")

        try:
            self.audio_stream = await asyncio.to_thread(
                pya.open,
                format=FORMAT,
                channels=CHANNELS,
                rate=SEND_SAMPLE_RATE,
                input=True,
                input_device_index=resolved_input_device_index if resolved_input_device_index is not None else mic_info["index"],
                frames_per_buffer=CHUNK_SIZE,
            )
        except OSError as e:
            print(f"[ADA] [ERR] Failed to open audio input stream: {e}")
            print("[ADA] [WARN] Audio features will be disabled. Please check microphone permissions.")
            return

        if __debug__:
            kwargs = {"exception_on_overflow": False}
        else:
            kwargs = {}
        
        # VAD Constants
        VAD_THRESHOLD = 800 # Adj based on mic sensitivity (800 is conservative for 16-bit)
        SILENCE_DURATION = 0.5 # Seconds of silence to consider "done speaking"
        
        while True:
            if self.paused:
                await asyncio.sleep(0.1)
                continue

            try:
                data = await asyncio.to_thread(self.audio_stream.read, CHUNK_SIZE, **kwargs)
                
                # EMOTION AI: Analyze audio for emotion detection
                if self.emotion_engine and self.emotion_engine.enable_voice:
                    try:
                        import numpy as np
                        audio_array = np.frombuffer(data, dtype=np.int16)
                        # Run emotion analysis in thread to avoid blocking
                        asyncio.create_task(self._analyze_user_emotion(audio_array))
                    except Exception as e:
                        pass  # Silent fail, emotion is optional
                
                # 1. Send Audio
                if self.out_queue:
                    await self.out_queue.put({"data": data, "mime_type": "audio/pcm"})
                
                # 2. VAD Logic for Video
                # rms = audioop.rms(data, 2)
                # Replacement for audioop.rms(data, 2)
                count = len(data) // 2
                if count > 0:
                    shorts = struct.unpack(f"<{count}h", data)
                    sum_squares = sum(s**2 for s in shorts)
                    rms = int(math.sqrt(sum_squares / count))
                else:
                    rms = 0
                
                if rms > VAD_THRESHOLD:
                    # Speech Detected
                    self._silence_start_time = None
                    
                    if not self._is_speaking:
                        # NEW Speech Utterance Started
                        self._is_speaking = True
                        print(f"[ADA DEBUG] [VAD] Speech Detected (RMS: {rms}). Sending Video Frame.")
                        
                        # Send ONE frame
                        if self._latest_image_payload and self.out_queue:
                            await self.out_queue.put(self._latest_image_payload)
                        else:
                            print(f"[ADA DEBUG] [VAD] No video frame available to send.")
                            
                else:
                    # Silence
                    if self._is_speaking:
                        if self._silence_start_time is None:
                            self._silence_start_time = time.time()
                        
                        elif time.time() - self._silence_start_time > SILENCE_DURATION:
                            # Silence confirmed, reset state
                            print(f"[ADA DEBUG] [VAD] Silence detected. Resetting speech state.")
                            self._is_speaking = False
                            self._silence_start_time = None

            except Exception as e:
                print(f"Error reading audio: {e}")
                await asyncio.sleep(0.1)

    async def handle_cad_request(self, prompt):
        print(f"[ADA DEBUG] [CAD] Background Task Started: handle_cad_request('{prompt}')")
        if self.on_cad_status:
            self.on_cad_status("generating")
            
        # Auto-create project if stuck in temp
        if self.project_manager.current_project == "temp":
            import datetime
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            new_project_name = f"Project_{timestamp}"
            print(f"[ADA DEBUG] [CAD] Auto-creating project: {new_project_name}")
            
            success, msg = self.project_manager.create_project(new_project_name)
            if success:
                self.project_manager.switch_project(new_project_name)
                # Notify User (Optional, or rely on update)
                try:
                    await self.session.send(input=f"System Notification: Automatic Project Creation. Switched to new project '{new_project_name}'.", end_of_turn=False)
                    if self.on_project_update:
                         self.on_project_update(new_project_name)
                except Exception as e:
                    print(f"[ADA DEBUG] [ERR] Failed to notify auto-project: {e}")

        # Get project cad folder path
        cad_output_dir = str(self.project_manager.get_current_project_path() / "cad")
        
        # Call the secondary agent with project path
        cad_data = await self.cad_agent.generate_prototype(prompt, output_dir=cad_output_dir)
        
        if cad_data:
            print(f"[ADA DEBUG] [OK] CadAgent returned data successfully.")
            print(f"[ADA DEBUG] [INFO] Data Check: {len(cad_data.get('vertices', []))} vertices, {len(cad_data.get('edges', []))} edges.")
            
            if self.on_cad_data:
                print(f"[ADA DEBUG] [SEND] Dispatching data to frontend callback...")
                self.on_cad_data(cad_data)
                print(f"[ADA DEBUG] [SENT] Dispatch complete.")
            
            # Save to Project
            if 'file_path' in cad_data:
                self.project_manager.save_cad_artifact(cad_data['file_path'], prompt)
            else:
                 # Fallback (legacy support)
                 self.project_manager.save_cad_artifact("output.stl", prompt)

            # Notify the model that the task is done - this triggers speech about completion
            completion_msg = "System Notification: CAD generation is complete! The 3D model is now displayed for the user. Let them know it's ready."
            try:
                await self.session.send(input=completion_msg, end_of_turn=True)
                print(f"[ADA DEBUG] [NOTE] Sent completion notification to model.")
            except Exception as e:
                 print(f"[ADA DEBUG] [ERR] Failed to send completion notification: {e}")

        else:
            print(f"[ADA DEBUG] [ERR] CadAgent returned None.")
            # Optionally notify failure
            try:
                await self.session.send(input="System Notification: CAD generation failed.", end_of_turn=True)
            except Exception:
                pass



    async def handle_write_file(self, path, content):
        print(f"[ADA DEBUG] [FS] Writing file: '{path}'")
        
        # Auto-create project if stuck in temp
        if self.project_manager.current_project == "temp":
            import datetime
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            new_project_name = f"Project_{timestamp}"
            print(f"[ADA DEBUG] [FS] Auto-creating project: {new_project_name}")
            
            success, msg = self.project_manager.create_project(new_project_name)
            if success:
                self.project_manager.switch_project(new_project_name)
                # Notify User
                try:
                    await self.session.send(input=f"System Notification: Automatic Project Creation. Switched to new project '{new_project_name}'.", end_of_turn=False)
                    if self.on_project_update:
                         self.on_project_update(new_project_name)
                except Exception as e:
                    print(f"[ADA DEBUG] [ERR] Failed to notify auto-project: {e}")
        
        # Force path to be relative to current project
        # If absolute path is provided, we try to strip it or just ignore it and use basename
        filename = os.path.basename(path)
        
        # If path contained subdirectories (e.g. "backend/server.py"), preserving that structure might be desired IF it's within the project.
        # But for safety, and per user request to "always create the file in the project", 
        # we will root it in the current project path.
        
        current_project_path = self.project_manager.get_current_project_path()
        final_path = current_project_path / filename # Simple flat structure for now, or allow relative?
        
        # If the user specifically wanted a subfolder, they might have provided "sub/file.txt".
        # Let's support relative paths if they don't start with /
        if not os.path.isabs(path):
             final_path = current_project_path / path
        
        print(f"[ADA DEBUG] [FS] Resolved path: '{final_path}'")

        try:
            # Ensure parent exists
            os.makedirs(os.path.dirname(final_path), exist_ok=True)
            with open(final_path, 'w', encoding='utf-8') as f:
                f.write(content)
            result = f"File '{final_path.name}' written successfully to project '{self.project_manager.current_project}'."
        except Exception as e:
            result = f"Failed to write file '{path}': {str(e)}"

        print(f"[ADA DEBUG] [FS] Result: {result}")
        try:
             await self.session.send(input=f"System Notification: {result}", end_of_turn=True)
        except Exception as e:
             print(f"[ADA DEBUG] [ERR] Failed to send fs result: {e}")

    async def handle_read_directory(self, path):
        print(f"[ADA DEBUG] [FS] Reading directory: '{path}'")
        try:
            if not os.path.exists(path):
                result = f"Directory '{path}' does not exist."
            else:
                items = os.listdir(path)
                result = f"Contents of '{path}': {', '.join(items)}"
        except Exception as e:
            result = f"Failed to read directory '{path}': {str(e)}"

        print(f"[ADA DEBUG] [FS] Result: {result}")
        try:
             await self.session.send(input=f"System Notification: {result}", end_of_turn=True)
        except Exception as e:
             print(f"[ADA DEBUG] [ERR] Failed to send fs result: {e}")

    async def handle_read_file(self, path):
        print(f"[ADA DEBUG] [FS] Reading file: '{path}'")
        try:
            if not os.path.exists(path):
                result = f"File '{path}' does not exist."
            else:
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()
                result = f"Content of '{path}':\n{content}"
        except Exception as e:
            result = f"Failed to read file '{path}': {str(e)}"

        print(f"[ADA DEBUG] [FS] Result: {result}")
        try:
             await self.session.send(input=f"System Notification: {result}", end_of_turn=True)
        except Exception as e:
             print(f"[ADA DEBUG] [ERR] Failed to send fs result: {e}")

    async def handle_web_agent_request(self, prompt):
        print(f"[ADA DEBUG] [WEB] Web Agent Task: '{prompt}'")
        
        async def update_frontend(image_b64, log_text):
            if self.on_web_data:
                 self.on_web_data({"image": image_b64, "log": log_text})
                 
        # Run the web agent and wait for it to return
        result = await self.web_agent.run_task(prompt, update_callback=update_frontend)
        print(f"[ADA DEBUG] [WEB] Web Agent Task Returned: {result}")
        
        # Send the final result back to the main model
        try:
             await self.session.send(input=f"System Notification: Web Agent has finished.\nResult: {result}", end_of_turn=True)
        except Exception as e:
             print(f"[ADA DEBUG] [ERR] Failed to send web agent result to model: {e}")

    async def receive_audio(self):
        "Background task to reads from the websocket and write pcm chunks to the output queue"
        try:
            while True:
                turn = self.session.receive()
                async for response in turn:
                    # 1. Handle Audio Data
                    if data := response.data:
                        self.audio_in_queue.put_nowait(data)
                        # NOTE: 'continue' removed here to allow processing transcription/tools in same packet

                    # 2. Handle Transcription (User & Model)
                    if response.server_content:
                        if response.server_content.input_transcription:
                            transcript = response.server_content.input_transcription.text
                            if transcript:
                                # Skip if this is an exact duplicate event
                                if transcript != self._last_input_transcription:
                                    # Calculate delta (Gemini may send cumulative or chunk-based text)
                                    delta = transcript
                                    if transcript.startswith(self._last_input_transcription):
                                        delta = transcript[len(self._last_input_transcription):]
                                    self._last_input_transcription = transcript
                                    
                                    # Only send if there's new text
                                    if delta:
                                        # User is speaking, so interrupt model playback!
                                        self.clear_audio_queue()

                                        # Send to frontend (Streaming) using role-safe emitter
                                        self.safe_emit_transcription("User", delta)
                                        
                                        # Buffer for Logging
                                        if self.chat_buffer["sender"] != "User":
                                            # Flush previous if exists
                                            if self.chat_buffer["sender"] and self.chat_buffer["text"].strip():
                                                self.project_manager.log_chat(self.chat_buffer["sender"], self.chat_buffer["text"])
                                            # Start new
                                            self.chat_buffer = {"sender": "User", "text": delta}
                                        else:
                                            # Append
                                            self.chat_buffer["text"] += delta
                        
                        if response.server_content.output_transcription:
                            transcript = response.server_content.output_transcription.text
                            if transcript:
                                # Skip if this is an exact duplicate event
                                if transcript != self._last_output_transcription:
                                    # Calculate delta (Gemini may send cumulative or chunk-based text)
                                    delta = transcript
                                    if transcript.startswith(self._last_output_transcription):
                                        delta = transcript[len(self._last_output_transcription):]
                                    self._last_output_transcription = transcript
                                    
                                    # Only send if there's new text
                                    if delta:
                                        # HALF-DUPLEX: Pause microphone when ADA first starts speaking
                                        if not self._ada_output_started:
                                            self.set_assistant_speaking(True)
                                            self._ada_output_started = True
                                        
                                        self._ada_output_text += delta  # Accumulate for tracking
                                        # ECHO PROTECTION: Store ADA's spoken text for echo detection
                                        import time
                                        self._last_assistant_spoken_text = transcript
                                        self._assistant_speak_timestamp = time.time()
                                        print(f"[ADA DEBUG] [ECHO PROTECTION] ADA spoke: '{transcript[:50]}...' at {self._assistant_speak_timestamp}")
                                        
                                        # Send to frontend (Streaming) using role-safe emitter
                                        self.safe_emit_transcription("ADA", delta)
                                        
                                        # Buffer for Logging
                                        if self.chat_buffer["sender"] != "ADA":
                                            # Flush previous
                                            if self.chat_buffer["sender"] and self.chat_buffer["text"].strip():
                                                self.project_manager.log_chat(self.chat_buffer["sender"], self.chat_buffer["text"])
                                            # Start new
                                            self.chat_buffer = {"sender": "ADA", "text": delta}
                                        else:
                                            # Append
                                            self.chat_buffer["text"] += delta
                        
                        # Flush buffer on turn completion if needed, 
                        # but usually better to wait for sender switch or explicit end.
                        # We can also check turn_complete signal if available in response.server_content.model_turn etc

                    # 3. Handle Tool Calls
                    if response.tool_call:
                        print("The tool was called")
                        function_responses = []
                        for fc in response.tool_call.function_calls:
                            if fc.name in ["generate_cad", "run_web_agent", "write_file", "read_directory", "read_file", "create_project", "switch_project", "list_projects", "list_smart_devices", "control_light", "discover_printers", "print_stl", "get_print_status", "iterate_cad", "system_control"]:
                                prompt = fc.args.get("prompt", "") # Prompt is not present for all tools
                                
                                # Load disable_confirmation from settings
                                import json
                                import os
                                disable_all_confirmations = False
                                try:
                                    settings_path = os.path.join(os.path.dirname(__file__), '..', 'settings.json')
                                    if os.path.exists(settings_path):
                                        with open(settings_path, 'r') as f:
                                            settings = json.load(f)
                                            disable_all_confirmations = settings.get('disable_confirmation', False)
                                except:
                                    pass
                                
                                # If disable_confirmation is True in settings, skip all confirmations
                                if disable_all_confirmations:
                                    print(f"[ADA DEBUG] [AUTO-AUTH] disable_confirmation=true in settings. Auto-authorizing ALL tools")
                                    confirmation_required = False
                                else:
                                    # Check Permissions (Default to True if not set)
                                    confirmation_required = self.permissions.get(fc.name, True)
                                    
                                    # DISABLE CONFIRMATION FOR SYSTEM_CONTROL - All actions auto-authorized
                                    if fc.name == "system_control":
                                        print(f"[ADA DEBUG] [AUTO-AUTH] System control - auto-authorizing all actions")
                                        confirmation_required = False
                                
                                if not confirmation_required:
                                    print(f"[ADA DEBUG] [TOOL] Permission check: '{fc.name}' -> AUTO-ALLOW")
                                    # Skip confirmation block and jump to execution
                                    pass
                                else:
                                    # Confirmation Logic
                                    if self.on_tool_confirmation:
                                        import uuid
                                        request_id = str(uuid.uuid4())
                                    print(f"[ADA DEBUG] [STOP] Requesting confirmation for '{fc.name}' (ID: {request_id})")
                                    
                                    future = asyncio.Future()
                                    self._pending_confirmations[request_id] = future
                                    
                                    self.on_tool_confirmation({
                                        "id": request_id, 
                                        "tool": fc.name, 
                                        "args": fc.args
                                    })
                                    
                                    try:
                                        # Wait for user response
                                        confirmed = await future

                                    finally:
                                        self._pending_confirmations.pop(request_id, None)

                                    print(f"[ADA DEBUG] [CONFIRM] Request {request_id} resolved. Confirmed: {confirmed}")

                                    if not confirmed:
                                        print(f"[ADA DEBUG] [DENY] Tool call '{fc.name}' denied by user.")
                                        function_response = types.FunctionResponse(
                                            id=fc.id,
                                            name=fc.name,
                                            response={
                                                "result": "User denied the request to use this tool.",
                                            }
                                        )
                                        function_responses.append(function_response)
                                        continue

                                    if not confirmed:
                                        print(f"[ADA DEBUG] [DENY] Tool call '{fc.name}' denied by user.")
                                        function_response = types.FunctionResponse(
                                            id=fc.id,
                                            name=fc.name,
                                            response={
                                                "result": "User denied the request to use this tool.",
                                            }
                                        )
                                        function_responses.append(function_response)
                                        continue

                                # If confirmed (or no callback configured, or auto-allowed), proceed
                                if fc.name == "generate_cad":
                                    print(f"\n[ADA DEBUG] --------------------------------------------------")
                                    print(f"[ADA DEBUG] [TOOL] Tool Call Detected: 'generate_cad'")
                                    print(f"[ADA DEBUG] [IN] Arguments: prompt='{prompt}'")
                                    
                                    asyncio.create_task(self.handle_cad_request(prompt))
                                    # No function response needed - model already acknowledged when user asked
                                
                                elif fc.name == "run_web_agent":
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'run_web_agent' with prompt='{prompt}'")
                                    asyncio.create_task(self.handle_web_agent_request(prompt))
                                    
                                    result_text = "Web Navigation started. Do not reply to this message."
                                    function_response = types.FunctionResponse(
                                        id=fc.id,
                                        name=fc.name,
                                        response={
                                            "result": result_text,
                                        }
                                    )
                                    print(f"[ADA DEBUG] [RESPONSE] Sending function response: {function_response}")
                                    function_responses.append(function_response)



                                elif fc.name == "write_file":
                                    path = fc.args["path"]
                                    content = fc.args["content"]
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'write_file' path='{path}'")
                                    asyncio.create_task(self.handle_write_file(path, content))
                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": "Writing file..."}
                                    )
                                    function_responses.append(function_response)

                                elif fc.name == "read_directory":
                                    path = fc.args["path"]
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'read_directory' path='{path}'")
                                    asyncio.create_task(self.handle_read_directory(path))
                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": "Reading directory..."}
                                    )
                                    function_responses.append(function_response)

                                elif fc.name == "read_file":
                                    path = fc.args["path"]
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'read_file' path='{path}'")
                                    asyncio.create_task(self.handle_read_file(path))
                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": "Reading file..."}
                                    )
                                    function_responses.append(function_response)

                                elif fc.name == "create_project":
                                    name = fc.args["name"]
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'create_project' name='{name}'")
                                    success, msg = self.project_manager.create_project(name)
                                    if success:
                                        # Auto-switch to the newly created project
                                        self.project_manager.switch_project(name)
                                        msg += f" Switched to '{name}'."
                                        if self.on_project_update:
                                            self.on_project_update(name)
                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": msg}
                                    )
                                    function_responses.append(function_response)

                                elif fc.name == "switch_project":
                                    name = fc.args["name"]
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'switch_project' name='{name}'")
                                    success, msg = self.project_manager.switch_project(name)
                                    if success:
                                        if self.on_project_update:
                                            self.on_project_update(name)
                                        # Gather project context and send to AI (silently, no response expected)
                                        context = self.project_manager.get_project_context()
                                        print(f"[ADA DEBUG] [PROJECT] Sending project context to AI ({len(context)} chars)")
                                        try:
                                            await self.session.send(input=f"System Notification: {msg}\n\n{context}", end_of_turn=False)
                                        except Exception as e:
                                            print(f"[ADA DEBUG] [ERR] Failed to send project context: {e}")
                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": msg}
                                    )
                                    function_responses.append(function_response)
                                
                                elif fc.name == "list_projects":
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'list_projects'")
                                    projects = self.project_manager.list_projects()
                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": f"Available projects: {', '.join(projects)}"}
                                    )
                                    function_responses.append(function_response)

                                elif fc.name == "list_smart_devices":
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'list_smart_devices'")
                                    # Use cached devices directly for speed
                                    # devices_dict is {ip: SmartDevice}
                                    
                                    dev_summaries = []
                                    frontend_list = []
                                    
                                    for ip, d in self.kasa_agent.devices.items():
                                        dev_type = "unknown"
                                        if d.is_bulb: dev_type = "bulb"
                                        elif d.is_plug: dev_type = "plug"
                                        elif d.is_strip: dev_type = "strip"
                                        elif d.is_dimmer: dev_type = "dimmer"
                                        
                                        # Format for Model
                                        info = f"{d.alias} (IP: {ip}, Type: {dev_type})"
                                        if d.is_on:
                                            info += " [ON]"
                                        else:
                                            info += " [OFF]"
                                        dev_summaries.append(info)
                                        
                                        # Format for Frontend
                                        frontend_list.append({
                                            "ip": ip,
                                            "alias": d.alias,
                                            "model": d.model,
                                            "type": dev_type,
                                            "is_on": d.is_on,
                                            "brightness": d.brightness if d.is_bulb or d.is_dimmer else None,
                                            "hsv": d.hsv if d.is_bulb and d.is_color else None,
                                            "has_color": d.is_color if d.is_bulb else False,
                                            "has_brightness": d.is_dimmable if d.is_bulb or d.is_dimmer else False
                                        })
                                    
                                    result_str = "No devices found in cache."
                                    if dev_summaries:
                                        result_str = "Found Devices (Cached):\n" + "\n".join(dev_summaries)
                                    
                                    # Trigger frontend update
                                    if self.on_device_update:
                                        self.on_device_update(frontend_list)

                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": result_str}
                                    )
                                    function_responses.append(function_response)

                                elif fc.name == "screen_read":
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'screen_read' (Camera Vision)")
                                    analyze_details = fc.args.get("analyze_details", True)
                                    read_aloud = fc.args.get("read_aloud", False)
                                    print(f"[ADA DEBUG] [CAMERA] analyze_details={analyze_details}, read_aloud={read_aloud}")

                                    camera = get_camera_module()
                                    try:
                                        scene_analysis = camera.describe_scene()
                                        if scene_analysis.get("success"):
                                            description = scene_analysis.get("description", "Camera view analyzed")
                                            if analyze_details:
                                                brightness = scene_analysis.get('brightness', {})
                                                edges = scene_analysis.get('edges', {})
                                                motion = scene_analysis.get('motion_potential', {})
                                                result_str = f"{description}. Brightness: {brightness.get('status', 'unknown')}. Activity level: {edges.get('activity', 'unknown')}. Motion detected: {motion.get('detected', False)}"
                                            else:
                                                result_str = description
                                        else:
                                            result_str = scene_analysis.get("error", "Failed to read camera")
                                    except Exception as e:
                                        result_str = f"Camera read error: {str(e)}"
                                        print(f"[ADA DEBUG] [CAMERA ERROR] {result_str}")

                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": result_str}
                                    )
                                    function_responses.append(function_response)
                                elif fc.name == "control_light":
                                    target = fc.args["target"]
                                    action = fc.args["action"]
                                    brightness = fc.args.get("brightness")
                                    color = fc.args.get("color")
                                    
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'control_light' Target='{target}' Action='{action}'")
                                    
                                    result_msg = f"Action '{action}' on '{target}' failed."
                                    success = False
                                    
                                    if action == "turn_on":
                                        success = await self.kasa_agent.turn_on(target)
                                        if success:
                                            result_msg = f"Turned ON '{target}'."
                                    elif action == "turn_off":
                                        success = await self.kasa_agent.turn_off(target)
                                        if success:
                                            result_msg = f"Turned OFF '{target}'."
                                    elif action == "set":
                                        success = True
                                        result_msg = f"Updated '{target}':"
                                    
                                    # Apply extra attributes if 'set' or if we just turned it on and want to set them too
                                    if success or action == "set":
                                        if brightness is not None:
                                            sb = await self.kasa_agent.set_brightness(target, brightness)
                                            if sb:
                                                result_msg += f" Set brightness to {brightness}."
                                        if color is not None:
                                            sc = await self.kasa_agent.set_color(target, color)
                                            if sc:
                                                result_msg += f" Set color to {color}."

                                    # Notify Frontend of State Change
                                    if success:
                                        # We don't need full discovery, just refresh known state or push update
                                        # But for simplicity, let's get the standard list representation
                                        # KasaAgent updates its internal state on control, so we can rebuild the list
                                        
                                        # Quick rebuild of list from internal dict
                                        updated_list = []
                                        for ip, dev in self.kasa_agent.devices.items():
                                            # We need to ensure we have the correct dict structure expected by frontend
                                            # We duplicate logic from KasaAgent.discover_devices a bit, but that's okay for now or we can add a helper
                                            # Ideally KasaAgent has a 'get_devices_list()' method.
                                            # Use the cached objects in self.kasa_agent.devices
                                            
                                            dev_type = "unknown"
                                            if dev.is_bulb: dev_type = "bulb"
                                            elif dev.is_plug: dev_type = "plug"
                                            elif dev.is_strip: dev_type = "strip"
                                            elif dev.is_dimmer: dev_type = "dimmer"

                                            d_info = {
                                                "ip": ip,
                                                "alias": dev.alias,
                                                "model": dev.model,
                                                "type": dev_type,
                                                "is_on": dev.is_on,
                                                "brightness": dev.brightness if dev.is_bulb or dev.is_dimmer else None,
                                                "hsv": dev.hsv if dev.is_bulb and dev.is_color else None,
                                                "has_color": dev.is_color if dev.is_bulb else False,
                                                "has_brightness": dev.is_dimmable if dev.is_bulb or dev.is_dimmer else False
                                            }
                                            updated_list.append(d_info)
                                            
                                        if self.on_device_update:
                                            self.on_device_update(updated_list)
                                    else:
                                        # Report Error
                                        if self.on_error:
                                            self.on_error(result_msg)

                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": result_msg}
                                    )
                                    function_responses.append(function_response)

                                elif fc.name == "discover_printers":
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'discover_printers'")
                                    printers = await self.printer_agent.discover_printers()
                                    # Format for model
                                    if printers:
                                        printer_list = []
                                        for p in printers:
                                            printer_list.append(f"{p['name']} ({p['host']}:{p['port']}, type: {p['printer_type']})")
                                        result_str = "Found Printers:\n" + "\n".join(printer_list)
                                    else:
                                        result_str = "No printers found on network. Ensure printers are on and running OctoPrint/Moonraker."
                                    
                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": result_str}
                                    )
                                    function_responses.append(function_response)

                                elif fc.name == "print_stl":
                                    stl_path = fc.args["stl_path"]
                                    printer = fc.args["printer"]
                                    profile = fc.args.get("profile")
                                    
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'print_stl' STL='{stl_path}' Printer='{printer}'")
                                    
                                    # Resolve 'current' to project STL
                                    if stl_path.lower() == "current":
                                        stl_path = "output.stl" # Let printer agent resolve it in root_path

                                    # Get current project path
                                    project_path = str(self.project_manager.get_current_project_path())
                                    
                                    result = await self.printer_agent.print_stl(
                                        stl_path, 
                                        printer, 
                                        profile, 
                                        root_path=project_path
                                    )
                                    result_str = result.get("message", "Unknown result")
                                    
                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": result_str}
                                    )
                                    function_responses.append(function_response)

                                elif fc.name == "get_print_status":
                                    printer = fc.args["printer"]
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'get_print_status' Printer='{printer}'")
                                    
                                    status = await self.printer_agent.get_print_status(printer)
                                    if status:
                                        result_str = f"Printer: {status.printer}\n"
                                        result_str += f"State: {status.state}\n"
                                        result_str += f"Progress: {status.progress_percent:.1f}%\n"
                                        if status.time_remaining:
                                            result_str += f"Time Remaining: {status.time_remaining}\n"
                                        if status.time_elapsed:
                                            result_str += f"Time Elapsed: {status.time_elapsed}\n"
                                        if status.filename:
                                            result_str += f"File: {status.filename}\n"
                                        if status.temperatures:
                                            temps = status.temperatures
                                            if "hotend" in temps:
                                                result_str += f"Hotend: {temps['hotend']['current']:.0f}°C / {temps['hotend']['target']:.0f}°C\n"
                                            if "bed" in temps:
                                                result_str += f"Bed: {temps['bed']['current']:.0f}°C / {temps['bed']['target']:.0f}°C"
                                    else:
                                        result_str = f"Could not get status for printer '{printer}'. Ensure it is discovered first."
                                    
                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": result_str}
                                    )
                                    function_responses.append(function_response)

                                elif fc.name == "iterate_cad":
                                    prompt = fc.args["prompt"]
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'iterate_cad' Prompt='{prompt}'")
                                    
                                    # Emit status
                                    if self.on_cad_status:
                                        self.on_cad_status("generating")
                                    
                                    # Get project cad folder path
                                    cad_output_dir = str(self.project_manager.get_current_project_path() / "cad")
                                    
                                    # Call CadAgent to iterate on the design
                                    cad_data = await self.cad_agent.iterate_prototype(prompt, output_dir=cad_output_dir)
                                    
                                    if cad_data:
                                        print(f"[ADA DEBUG] [OK] CadAgent iteration returned data successfully.")
                                        
                                        # Dispatch to frontend
                                        if self.on_cad_data:
                                            print(f"[ADA DEBUG] [SEND] Dispatching iterated CAD data to frontend...")
                                            self.on_cad_data(cad_data)
                                            print(f"[ADA DEBUG] [SENT] Dispatch complete.")
                                        
                                        # Save to Project
                                        self.project_manager.save_cad_artifact("output.stl", f"Iteration: {prompt}")
                                        
                                        result_str = f"Successfully iterated design: {prompt}. The updated 3D model is now displayed."
                                    else:
                                        print(f"[ADA DEBUG] [ERR] CadAgent iteration returned None.")
                                        result_str = f"Failed to iterate design with prompt: {prompt}"
                                    
                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": result_str}
                                    )
                                    function_responses.append(function_response)

                                elif fc.name == "whatsapp_control":
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'whatsapp_control'")
                                    action = fc.args.get("action", "")
                                    contact = fc.args.get("contact", "")
                                    message = fc.args.get("message", "")
                                    print(f"[ADA DEBUG] [WHATSAPP] Action: '{action}', Contact: '{contact}', Message: '{message}'")
                                    
                                    whatsapp_agent = get_whatsapp_agent()
                                    result_str = ""
                                    
                                    try:
                                        if action == "send_message":
                                            if not contact or not message:
                                                result_str = "Contact name and message are required for sending messages"
                                            else:
                                                result = whatsapp_agent.send_message(contact, message)
                                                result_str = result.get("message") if result.get("success") else result.get("error", "Failed to send message")
                                        elif action == "video_call":
                                            if not contact:
                                                result_str = "Contact name is required for video call"
                                            else:
                                                result = whatsapp_agent.video_call(contact)
                                                result_str = result.get("message") if result.get("success") else result.get("error", "Failed to initiate video call")
                                        elif action == "voice_call":
                                            if not contact:
                                                result_str = "Contact name is required for voice call"
                                            else:
                                                result = whatsapp_agent.voice_call(contact)
                                                result_str = result.get("message") if result.get("success") else result.get("error", "Failed to initiate voice call")
                                        else:
                                            result_str = f"Unknown WhatsApp action: {action}"
                                    except Exception as e:
                                        result_str = f"WhatsApp error: {str(e)}"
                                        print(f"[ADA DEBUG] [WHATSAPP ERROR] {result_str}")
                                    
                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": result_str}
                                    )
                                    function_responses.append(function_response)

                                elif fc.name == "media_play":
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'media_play'")
                                    platform = fc.args.get("platform", "").lower()
                                    query = fc.args.get("query", "")
                                    print(f"[ADA DEBUG] [MEDIA] Platform: '{platform}', Query: '{query}'")
                                    
                                    media_controller = MediaController()
                                    result_str = ""
                                    
                                    try:
                                        if platform == "spotify":
                                            if not query:
                                                result_str = "Search query is required for Spotify"
                                            else:
                                                result = media_controller.spotify_play(query)
                                                result_str = f"Now playing '{query}' on Spotify" if result.get("success") else result.get("error", "Failed to play on Spotify")
                                        elif platform == "youtube":
                                            if not query:
                                                result_str = "Search query is required for YouTube"
                                            else:
                                                result = media_controller.youtube_play(query)
                                                result_str = f"Opening YouTube and playing '{query}'" if result.get("success") else result.get("error", "Failed to open YouTube")
                                        else:
                                            result_str = f"Unknown platform: {platform}. Use 'spotify' or 'youtube'"
                                    except Exception as e:
                                        result_str = f"Media control error: {str(e)}"
                                        print(f"[ADA DEBUG] [MEDIA ERROR] {result_str}")
                                    
                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": result_str}
                                    )
                                    function_responses.append(function_response)

                                elif fc.name == "system_control":
                                    print(f"[ADA DEBUG] [TOOL] Tool Call: 'system_control'")
                                    action = fc.args.get("action", "")
                                    params = fc.args.get("params", {})
                                    print(f"[ADA DEBUG] [SYSTEM] Action: '{action}', Params: {params}")
                                    
                                    # Check system control permissions
                                    system_agent = get_system_agent()
                                    
                                    # Check permissions
                                    # Default to True when key is missing (safer for users who expect permissions enabled)
                                    has_system_control = self.permissions.get("system_control", True)
                                    has_screen_access = self.permissions.get("screen_access", True)
                                    has_file_access = self.permissions.get("file_access", True)
                                    
                                    print(f"[ADA DEBUG] [PERM CHECK] system_control={has_system_control}, screen_access={has_screen_access}, file_access={has_file_access}")
                                    print(f"[ADA DEBUG] [PERM CHECK] Full permissions dict: {self.permissions}")
                                    
                                    if not has_system_control:
                                        result_str = "System control is disabled. Please enable 'system_control' permission in settings to use this feature."
                                        print(f"[ADA DEBUG] [DENY] System control disabled by permission")
                                    elif action == "capture_screen":
                                        if not has_screen_access:
                                            result_str = "Screen access is disabled. Please enable 'screen_access' permission to capture screenshots."
                                        else:
                                            screen_data = system_agent.capture_screen()
                                            if screen_data.get("success"):
                                                result_str = f"Screenshot captured: {screen_data.get('size')} pixels. Image data sent to frontend."
                                                if self.on_system_data:
                                                    self.on_system_data({"type": "screenshot", "data": screen_data})
                                            else:
                                                result_str = f"Screenshot failed: {screen_data.get('error', 'Unknown error')}"
                                    elif action == "open_app":
                                        app_name = params.get("app_name", "")
                                        if not app_name:
                                            result_str = "App name not specified"
                                        else:
                                            result = system_agent.open_app(app_name)
                                            result_str = result.get("message") if result.get("success") else result.get("error", "Failed to open app")
                                    elif action == "open_file":
                                        if not has_file_access:
                                            result_str = "File access is disabled. Please enable 'file_access' permission to open files."
                                        else:
                                            file_path = params.get("file_path", "")
                                            if not file_path:
                                                result_str = "File path not specified"
                                            else:
                                                result = system_agent.open_file(file_path)
                                                result_str = result.get("message") if result.get("success") else result.get("error", "Failed to open file")
                                    elif action == "open_folder":
                                        if not has_file_access:
                                            result_str = "File access is disabled. Please enable 'file_access' permission to open folders."
                                        else:
                                            folder_path = params.get("folder_path", "")
                                            if not folder_path:
                                                result_str = "Folder path not specified"
                                            else:
                                                result = system_agent.open_folder(folder_path)
                                                result_str = result.get("message") if result.get("success") else result.get("error", "Failed to open folder")
                                    elif action == "find_file":
                                        if not has_file_access:
                                            result_str = "File access is disabled. Please enable 'file_access' permission to search for files."
                                        else:
                                            file_name = params.get("file_name", "")
                                            search_paths = params.get("search_paths", None)
                                            if not file_name:
                                                result_str = "File name not specified"
                                            else:
                                                result = system_agent.find_file(file_name, search_paths)
                                                if result.get("success"):
                                                    result_str = f"File found: {result.get('path')}"
                                                else:
                                                    result_str = result.get("error", "File not found")
                                    elif action == "type_text":
                                        text = params.get("text", "")
                                        delay = params.get("delay", 0.05)
                                        if not text:
                                            result_str = "Text not specified"
                                        else:
                                            result = system_agent.type_text(text, delay)
                                            result_str = result.get("message") if result.get("success") else result.get("error", "Failed to type text")
                                    elif action == "control_volume":
                                        level = params.get("level", 50)
                                        result = system_agent.control_volume(level)
                                        result_str = result.get("message") if result.get("success") else result.get("error", "Failed to control volume")
                                    elif action == "control_brightness":
                                        level = params.get("level", 50)
                                        result = system_agent.control_brightness(level)
                                        result_str = result.get("message") if result.get("success") else result.get("error", "Failed to control brightness")
                                    elif action == "click_mouse":
                                        x = params.get("x")
                                        y = params.get("y")
                                        result = system_agent.click_mouse(x, y)
                                        result_str = result.get("message") if result.get("success") else result.get("error", "Failed to click mouse")
                                    elif action == "press_key":
                                        key = params.get("key", "")
                                        if not key:
                                            result_str = "Key not specified"
                                        else:
                                            result = system_agent.press_key(key)
                                            result_str = result.get("message") if result.get("success") else result.get("error", "Failed to press key")
                                    elif action == "get_capabilities":
                                        capabilities = system_agent.get_system_capabilities()
                                        result_str = f"System capabilities: {capabilities}"
                                    else:
                                        result_str = f"Unknown system action: {action}"
                                    
                                    function_response = types.FunctionResponse(
                                        id=fc.id, name=fc.name, response={"result": result_str}
                                    )
                                    function_responses.append(function_response)
                        if function_responses:
                            await self.session.send_tool_response(function_responses=function_responses)
                
                # Turn/Response Loop Finished
                self.flush_chat()
                
                # HALF-DUPLEX: Resume microphone when ADA finishes speaking
                if self.assistant_speaking:
                    self.set_assistant_speaking(False)
                    self._ada_output_started = False
                    self._ada_output_text = ""

                while not self.audio_in_queue.empty():
                    self.audio_in_queue.get_nowait()
        except Exception as e:
            print(f"Error in receive_audio: {e}")
            traceback.print_exc()
            # CRITICAL: Re-raise to crash the TaskGroup and trigger outer loop reconnect
            raise e

    async def play_audio(self):
        stream = await asyncio.to_thread(
            pya.open,
            format=FORMAT,
            channels=CHANNELS,
            rate=RECEIVE_SAMPLE_RATE,
            output=True,
            output_device_index=self.output_device_index,
        )
        while True:
            bytestream = await self.audio_in_queue.get()
            if self.on_audio_data:
                self.on_audio_data(bytestream)
            await asyncio.to_thread(stream.write, bytestream)

    async def get_frames(self):
        cap = await asyncio.to_thread(cv2.VideoCapture, 0, cv2.CAP_AVFOUNDATION)
        while True:
            if self.paused:
                await asyncio.sleep(0.1)
                continue
            frame = await asyncio.to_thread(self._get_frame, cap)
            if frame is None:
                break
            await asyncio.sleep(1.0)
            if self.out_queue:
                await self.out_queue.put(frame)
        cap.release()

    def _get_frame(self, cap):
        ret, frame = cap.read()
        if not ret:
            return None
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = PIL.Image.fromarray(frame_rgb)
        img.thumbnail([1024, 1024])
        image_io = io.BytesIO()
        img.save(image_io, format="jpeg")
        image_io.seek(0)
        image_bytes = image_io.read()
        return {"mime_type": "image/jpeg", "data": base64.b64encode(image_bytes).decode()}

    async def _get_screen(self):
        pass 
    async def get_screen(self):
         pass

    async def run(self, start_message=None):
        retry_delay = 1
        is_reconnect = False
        
        while not self.stop_event.is_set():
            try:
                print(f"[ADA DEBUG] [CONNECT] Connecting to Gemini Live API...")
                async with (
                    client.aio.live.connect(model=MODEL, config=config) as session,
                    asyncio.TaskGroup() as tg,
                ):
                    self.session = session

                    self.audio_in_queue = asyncio.Queue()
                    self.out_queue = asyncio.Queue(maxsize=10)

                    tg.create_task(self.send_realtime())
                    tg.create_task(self.listen_audio())
                    # tg.create_task(self._process_video_queue()) # Removed in favor of VAD

                    if self.video_mode == "camera":
                        tg.create_task(self.get_frames())
                    elif self.video_mode == "screen":
                        tg.create_task(self.get_screen())

                    tg.create_task(self.receive_audio())
                    tg.create_task(self.play_audio())

                    # Handle Startup vs Reconnect Logic
                    if not is_reconnect:
                        if start_message:
                            print(f"[ADA DEBUG] [INFO] Sending start message: {start_message}")
                            await self.session.send(input=start_message, end_of_turn=True)
                        
                        # Sync Project State
                        if self.on_project_update and self.project_manager:
                            self.on_project_update(self.project_manager.current_project)
                    
                    else:
                        print(f"[ADA DEBUG] [RECONNECT] Connection restored.")
                        # Restore Context
                        print(f"[ADA DEBUG] [RECONNECT] Fetching recent chat history to restore context...")
                        history = self.project_manager.get_recent_chat_history(limit=10)
                        
                        context_msg = "System Notification: Connection was lost and just re-established. Here is the recent chat history to help you resume seamlessly:\n\n"
                        for entry in history:
                            sender = entry.get('sender', 'Unknown')
                            text = entry.get('text', '')
                            context_msg += f"[{sender}]: {text}\n"
                        
                        context_msg += "\nPlease acknowledge the reconnection to the user (e.g. 'I lost connection for a moment, but I'm back...') and resume what you were doing."
                        
                        print(f"[ADA DEBUG] [RECONNECT] Sending restoration context to model...")
                        await self.session.send(input=context_msg, end_of_turn=True)

                    # Reset retry delay on successful connection
                    retry_delay = 1
                    
                    # Wait until stop event, or until the session task group exits (which happens on error)
                    # Actually, the TaskGroup context manager will exit if any tasks fail/cancel.
                    # We need to keep this block alive.
                    # The original code just waited on stop_event, but that doesn't account for session death.
                    # We should rely on the TaskGroup raising an exception when subtasks fail (like receive_audio).
                    
                    # However, since receive_audio is a task in the group, if it crashes (connection closed), 
                    # the group will cancel others and exit. We catch that exit below.
                    
                    # We can await stop_event, but if the connection dies, receive_audio crashes -> group closes -> we exit `async with` -> restart loop.
                    # To ensure we don't block indefinitely if connection dies silently (unlikely with receive_audio), we just wait.
                    await self.stop_event.wait()

            except asyncio.CancelledError:
                print(f"[ADA DEBUG] [STOP] Main loop cancelled.")
                break
                
            except Exception as e:
                # This catches the ExceptionGroup from TaskGroup or direct exceptions
                print(f"[ADA DEBUG] [ERR] Connection Error: {e}")
                
                if self.stop_event.is_set():
                    break
                
                print(f"[ADA DEBUG] [RETRY] Reconnecting in {retry_delay} seconds...")
                await asyncio.sleep(retry_delay)
                retry_delay = min(retry_delay * 2, 10) # Exponential backoff capped at 10s
                is_reconnect = True # Next loop will be a reconnect
                
            finally:
                # Cleanup before retry
                if hasattr(self, 'audio_stream') and self.audio_stream:
                    try:
                        self.audio_stream.close()
                    except: 
                        pass

def get_input_devices():
    p = pyaudio.PyAudio()
    info = p.get_host_api_info_by_index(0)
    numdevices = info.get('deviceCount')
    devices = []
    for i in range(0, numdevices):
        if (p.get_device_info_by_host_api_device_index(0, i).get('maxInputChannels')) > 0:
            devices.append((i, p.get_device_info_by_host_api_device_index(0, i).get('name')))
    p.terminate()
    return devices

def get_output_devices():
    p = pyaudio.PyAudio()
    info = p.get_host_api_info_by_index(0)
    numdevices = info.get('deviceCount')
    devices = []
    for i in range(0, numdevices):
        if (p.get_device_info_by_host_api_device_index(0, i).get('maxOutputChannels')) > 0:
            devices.append((i, p.get_device_info_by_host_api_device_index(0, i).get('name')))
    p.terminate()
    return devices

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode",
        type=str,
        default=DEFAULT_MODE,
        help="pixels to stream from",
        choices=["camera", "screen", "none"],
    )
    args = parser.parse_args()
    main = AudioLoop(video_mode=args.mode)
    asyncio.run(main.run())